# Shaolin Shuffle 0.6.2 (Enemy Randomizer)

Shuffles enemy types across **every spawn slot in the area**. Most rooms get a
different mix, and the game uses exactly as much enemy memory as vanilla.



## 0.6: works in memory-tight areas

The 0.5 rule required an exact match of every behaviour field before an
enemy's type could change. In practice each enemy type carries its own patrol
and navmesh values, so every type ended up in its own class. The shuffle had nothing to swap with, so rooms looked unchanged. Now only
entries with a special entrance (spawn-near-player flag `+0x58`, initial AI
state `+0x5C` such as climbing in, mover data `+0x10`) keep the strict match.
Plain entries can take any regular enemy that the area also spawns from plain
entries. Climb-in and other special slots stay with the type they were made for.

## 0.5: softlock fix

0.4 could move an enemy into a spawn slot built for another type's entrance,
like a wall-climber's slot outside the arena. That left it stuck out of bounds,
unkillable, so the area never cleared. 0.5 only swaps types between entries
with identical behaviour (entrance flag, initial AI state, patrol, navmesh,
mover data). The shuffle now runs in the next spawn tick, its own callback.

## Why it changed

Enemy model memory is never freed when an enemy dies. Each type's pool is
sized for how many of that type the area spawns in total. 0.3 picked random
new types, which used up some types' memory and could crash later. It also
had to skip most re-rolls, which is why some rooms looked normal.

0.4 permutes the types the area already has. If an area has 10 spear guys
and 10 monks, it still has 10 of each, just in different places. Totals never
change, so memory never runs out, however much moves around.

- Each area is shuffled once, in a single pass, the first time a group starts.
- Entries are swapped so as few as possible keep their own type.
- Bosses and once-per-area elites stay where they are. Players and allies
  are never included.
- Groups that already ran (and the first group of the area) aren't changed.
- A reload is detected and reshuffled.

An area that only has one common enemy type can't change. There's nothing to
swap with. Bringing in characters from other levels is still on the list.

Compatible with Legendary Dark Knight Mode 3.0.
Requires Shaolin Monks Recomp 0.2.0 or later.

## 0.6.1: bosses stay put

The Oni Warlord is authored twice in its area, so 0.6 counted it as a
regular enemy and could shuffle it into a grunt's spawn entry outside the
arena. Bosses (super bosses and MK characters, listed in `core.lua`) are now
never part of the shuffle.

## 0.6.2

Shares LDK 3.7's memory code (`core.lua`); Shuffle's own behaviour is
unchanged. Areas with only one regular enemy type, like Goro's Lair (24 of
one type), still look unshuffled: there's nothing to swap with. Bringing in
enemies from other levels is the next Shuffle feature.

## 0.6.4 (v1 patch 2): enemies no longer go missing in tight areas

The shared last-resort memory guard could cancel every spawn of an enemy type
in a room. Goro's Lair's fatality room and the room after it got no enemies,
so their gates never opened. The guard used a memory cost measured in an
earlier map, and it ignored that the game reuses a dead enemy's memory. It
now counts reusable memory per memory pool, for as long as the pool lives,
and trusts reuse once it has seen it happen. The memory cost itself still
carries over between maps, so the guard keeps protecting new areas.

## 0.6.5 (v1 patch 3): the Reptile fight stays vanilla

Reptile's human form (character 82) wasn't on the boss list, so Boss Invasion
treated him as an ordinary elite and doubled his fight. With two Reptiles
spamming projectiles and turning invisible, and one of them out of bounds,
the fight couldn't be won. He's a boss now: never cloned, never an invader,
never shuffled. A double Reptile can come back later as an opt-in challenge.

## 0.6.6 (v1 patch 4): Reptile, for real

The story Reptile fight (map 144) uses character 59, authored in three of the
map's waves. LDK counted him as a common enemy and cloned him, so the fight
had two or three Reptiles. Character 59 is now a boss as well.
