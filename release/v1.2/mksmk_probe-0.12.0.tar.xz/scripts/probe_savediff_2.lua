-- ===== MKSMK Probe save-triggered reporting (shared by every probe script) =====
-- A routine script can only write to the game log by failing with an error,
-- and that also disables it for the rest of the session: one report per
-- script per session. So each probe collects quietly and writes its report
-- when the game saves. Every save ends in 0x1272A0, the HardDisk write: it
-- creates the save container (SaveMeta.xbx) and opens save.dat with
-- GENERIC_WRITE. (0x127420 is the matching read; 0.8.0 hooked 0xA2260, a
-- save path the statue does not use.) Play, test, save at a statue, quit.
-- A script with nothing collected yet waits for the next save. The log keeps
-- the first LOG_HEAD and the last LOG_TAIL entries plus a count of the ones
-- dropped in between, so a long session stays bounded.
local SAVE_GAME  = 0x001272A0
local SAVE_INDEX = 2          -- this copy reports at the SAVE_INDEX-th save (build.py makes copies)
local LOG_HEAD   = 100
local LOG_TAIL   = 400

-- 0.10: a script still reports only once, so build.py ships copies with
-- SAVE_INDEX 1, 2 and 3. Each copy reports at that save of the session (or the
-- next save after it, if it had nothing yet) and holds everything since the
-- game started.
local saves_seen = 0
local function save_due()
    saves_seen = saves_seen + 1
    return saves_seen >= SAVE_INDEX
end
local function save_tag(reason)
    return reason .. "#" .. SAVE_INDEX
end

local log_head, log_ring = {}, {}
local log_ring_n, log_ring_at, log_total = 0, 0, 0

local function log_add(text)
    log_total = log_total + 1
    if #log_head < LOG_HEAD then
        log_head[#log_head + 1] = text
        return
    end
    log_ring_at = log_ring_at % LOG_TAIL + 1
    log_ring[log_ring_at] = text
    if log_ring_n < LOG_TAIL then log_ring_n = log_ring_n + 1 end
end

local function log_count()
    return log_total
end

local function log_text()
    local out = {}
    for i = 1, #log_head do out[#out + 1] = log_head[i] end
    local dropped = log_total - #log_head - log_ring_n
    if dropped > 0 then out[#out + 1] = "...(" .. dropped .. " dropped)..." end
    local start = log_ring_n < LOG_TAIL and 1 or (log_ring_at % LOG_TAIL + 1)
    for k = 0, log_ring_n - 1 do
        out[#out + 1] = log_ring[(start - 1 + k) % LOG_TAIL + 1]
    end
    return table.concat(out, " ")
end
-- MKSMK Probe: save-data watcher (diagnostics only, changes nothing).
-- The game manager [0x5ACEBC] is also the save data: event flags at +0x4874,
-- the player character IDs at +0xCC/+0xD0, and (to be found) XP, upgrades and
-- abilities. This script snapshots WATCH_BYTES of it, one slice per frame,
-- then keeps comparing slice by slice. Every dword that changes is recorded
-- with its first value, its latest value and how often it changed. The report
-- (written when the game saves, probe_save.lua) lists them by offset. Unlock an
-- ability, buy an upgrade or gain XP, then save: the offsets that moved are the
-- fields. Matched against archived save.dat files it maps file offsets to
-- memory. A new game manager pointer (new game, load) starts a new baseline.
local GAME_MANAGER = 0x005ACEBC
local CHECK        = 0x0016F4B0   -- runs every frame in gameplay; drives the scan
local FRAME        = 0x005CE878
local WATCH_BYTES  = 0x8000
local SLICE_DWORDS = 256
local CHANGE_CAP   = 600          -- distinct offsets kept

local function ok(p)
    return p >= 0x10000 and p % 4 == 0 and (p < 0x7FFE0000 or (p >= 0x80000000 and p < 0x84000000)
        or (p >= 0xB0000000 and p < 0xC0000000) or (p >= 0xD0000000 and p < 0xE0000000)
        or (p >= 0xF0000000 and p < 0xF4000000))
end
local function hex(v) return string.format("%X", v) end

local DWORDS = WATCH_BYTES // 4
local base, baseline, built, cursor, last_frame = nil, {}, 0, 0, nil
local changes, change_count, rebases = {}, 0, 0
local done = false

local function step()
    local frame = game.read_u32(FRAME)
    if frame == last_frame then return end
    last_frame = frame
    local gm = game.read_u32(GAME_MANAGER)
    if not ok(gm) then return end
    if gm ~= base then
        base, baseline, built, cursor = gm, {}, 0, 0
        rebases = rebases + 1
    end
    if built < DWORDS then
        local stop = math.min(built + SLICE_DWORDS, DWORDS)
        for i = built, stop - 1 do baseline[i] = game.read_u32(base + i * 4) end
        built = stop
        return
    end
    local stop = math.min(cursor + SLICE_DWORDS, DWORDS)
    for i = cursor, stop - 1 do
        local v = game.read_u32(base + i * 4)
        local c = changes[i]
        if c then
            if v ~= c.last then c.last = v; c.n = c.n + 1 end
        elseif v ~= baseline[i] and change_count < CHANGE_CAP then
            changes[i] = { first = baseline[i], last = v, n = 1 }
            change_count = change_count + 1
        end
    end
    cursor = stop % DWORDS
end

local function report(reason)
    done = true
    local list = {}
    for i in pairs(changes) do list[#list + 1] = i end
    table.sort(list)
    local parts = {}
    for _, i in ipairs(list) do
        local c = changes[i]
        parts[#parts + 1] = "+" .. hex(i * 4) .. ":" .. hex(c.first) .. ">" .. hex(c.last) .. "(" .. c.n .. ")"
    end
    error("SAVEDIFF " .. reason .. " gm=" .. hex(base or 0) .. " rebases=" .. rebases
        .. " watched=" .. hex(built * 4) .. " changed=" .. change_count
        .. " | " .. table.concat(parts, " "), 0)
end

return {
    {   address = CHECK,
        before = function(ctx)
            if not done then step() end
        end },
    {   address = SAVE_GAME,
        before = function(ctx)
            if save_due() and not done and change_count > 0 then report(save_tag("save")) end
        end },
}
