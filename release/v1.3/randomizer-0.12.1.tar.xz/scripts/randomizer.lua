-- ===== shared spawn core v2 (identical in ldk, ldk_bosses and randomizer) =====
-- Spawn manager: 50 group records, 0xA6C bytes apart. A group holds 23 entry
-- slots of 0x74 bytes from +0x18; the signed 16-bit count at +0xA68 sits in
-- the last slot, so 22 slots are usable. Entry fields used here:
--   +0x00 enemy type   +0x5A u16 spawn delay in frames after the group start
-- The spawn tick (0x1D23F0) spawns entries in order once start+delay has
-- passed, and stops at the first entry that is not yet due.
local MANAGER        = 0x006DBFB0
local GROUP_STRIDE   = 0xA6C
local GROUP_LIMIT    = 50
local MANAGER_END    = MANAGER + GROUP_LIMIT * GROUP_STRIDE
local ENTRY_BASE     = 0x18
local ENTRY_STRIDE   = 0x74
local ENTRY_SLOTS    = 22
local COUNT_OFFSET   = 0xA68
local ENABLED_OFFSET = 0xA6A
local DELAY_OFFSET   = 0x5A
local ST_START       = 0x2091C
local ST_GROUP       = 0x20920
local ST_SPAWNED     = 0x20922
local ST_CONTROLLER  = 0x20924
local ST_ACTIVE      = 0x2092A
local ST_FORCE       = 0x2092C
local CTRL_ALIVE     = 0xA0
local FRAME_COUNTER  = 0x005CE878
-- Actor creation (0x16C550) refuses any type missing from this six-slot
-- table (0x1C1580), so it is the set of enemy types that can spawn right now.
local LOADED_TYPES   = 0x006CA69C
local LOADED_SLOTS   = 6
local NO_TYPE        = 0xFFFFFFFF
-- Character pool (0x510040): 12 slots including both players. Flags are a
-- u16 array at [pool+0x0C]; a zero flag is a free slot (0x16B630).
local CHAR_POOL      = 0x00510040
local CHAR_FLAGS     = 0x0C
local CHAR_POOL_SIZE = 0x005142A4

-- Guest memory on the Recomp is a 4 GiB space: game and user allocations
-- below 0x7FFE0000, physical RAM at 0x80000000 and 0xF0000000 (64 MiB each),
-- system pools at 0xB0000000 and thread stacks at 0xD0000000.
local function plausible(p)
    if p < 0x10000 or p % 4 ~= 0 then
        return false
    end
    return p < 0x7FFE0000
        or (p >= 0x80000000 and p < 0x84000000)
        or (p >= 0xB0000000 and p < 0xC0000000)
        or (p >= 0xD0000000 and p < 0xE0000000)
        or (p >= 0xF0000000 and p < 0xF4000000)
end

local function group_base(index)
    return MANAGER + index * GROUP_STRIDE
end

local function entry_address(group, slot)
    return group_base(group) + ENTRY_BASE + slot * ENTRY_STRIDE
end

-- Group and slot of an entry address inside the spawn manager, or nil.
local function entry_index(entry)
    if entry < MANAGER + ENTRY_BASE or entry >= MANAGER_END then
        return nil
    end
    local group = (entry - MANAGER) // GROUP_STRIDE
    local offset = (entry - MANAGER) % GROUP_STRIDE - ENTRY_BASE
    if offset < 0 or offset % ENTRY_STRIDE ~= 0 or offset // ENTRY_STRIDE >= ENTRY_SLOTS then
        return nil
    end
    return group, offset // ENTRY_STRIDE
end

local function group_count(base)
    local count = game.read_u16(base + COUNT_OFFSET)
    if count > ENTRY_SLOTS then
        return nil
    end
    return count
end

local rng_state = 0x2C9277B5

local function rnd()
    local x = rng_state
    x = x ~ ((x << 13) & 0xFFFFFFFF)
    x = x ~ (x >> 17)
    x = x ~ ((x << 5) & 0xFFFFFFFF)
    rng_state = x & 0xFFFFFFFF
    return rng_state
end

local function reseed(value)
    local seed = (value ~ game.read_u32(FRAME_COUNTER)) & 0xFFFFFFFF
    if seed == 0 then
        seed = 0x2C9277B5
    end
    rng_state = seed
    rnd()
end

-- Character memory slots (cGameMemInterface 0x6322F8): [+0x10] slot count,
-- [+0x24] table of 20-byte slots {heap id, enemy type, ...}. Each loaded enemy
-- type owns one slot, and its models are carved from that slot's heap when
-- an actor is created (0x1D7880 -> 0x114730). An exhausted heap returns null
-- there and the game crashes, so every spawn is checked against the real heap.
local INTERFACE      = 0x006322F8
local SLOT_COUNT     = 0x10
local SLOT_TABLE     = 0x24
local SLOT_STRIDE    = 20
local SLOT_TYPE      = 4
local HEAP_REGISTRY  = 0x0062EC60
local HEAP_STRIDE    = 0x68
local HEAP_TOTAL     = 0x04
local HEAP_CURRENT   = 0x08
local HEAP_END       = 0x0C
local HEAP_FRAGMENT  = 0x1C
local HEAP_LIST      = 0x20
local HEAP_MARGIN    = 0x4000

-- Free bytes (sum) and largest free block of a game heap, or nil.
local function heap_space(heap)
    if heap >= 0x80 then
        return nil
    end
    local record = HEAP_REGISTRY + heap * HEAP_STRIDE
    local total = game.read_u32(record + HEAP_TOTAL)
    if total == 0 or total > 0x10000000 then
        return nil
    end
    if game.read_u32(record + HEAP_FRAGMENT) ~= 0 then
        local node = game.read_u32(record + HEAP_LIST)
        local free, largest, walked = 0, 0, 0
        while node ~= 0 do
            if not plausible(node) or walked >= 256 then
                return nil
            end
            local first = game.read_u32(node + 8)
            local last = game.read_u32(node + 0xC)
            if last > first then
                free = free + (last - first)
                if last - first > largest then
                    largest = last - first
                end
            end
            node = game.read_u32(node + 4)
            walked = walked + 1
        end
        return free, largest
    end
    local current = game.read_u32(record + HEAP_CURRENT)
    local last = game.read_u32(record + HEAP_END)
    if last < current then
        return nil
    end
    return last - current, last - current
end

local function slot_table()
    local count = game.read_u32(INTERFACE + SLOT_COUNT)
    local table_ptr = game.read_u32(INTERFACE + SLOT_TABLE)
    if count == 0 or count > 16 or not plausible(table_ptr) then
        return nil, 0
    end
    return table_ptr, count
end

local function heap_of(kind)
    local table_ptr, count = slot_table()
    if table_ptr == nil then
        return nil
    end
    for slot = 0, count - 1 do
        local base = table_ptr + slot * SLOT_STRIDE
        if game.read_u32(base + SLOT_TYPE) == kind then
            local heap = game.read_u32(base)
            if heap < 0x80 then
                return heap
            end
            return nil
        end
    end
    return nil
end

-- Bytes one actor of each type took from its heap, measured on real spawns.
-- Model memory is never returned when an enemy dies (the probe showed every
-- slot heap only shrinking until the area reloads), so each extra enemy
-- permanently uses memory that a later authored spawn of that type needs.
local costs = {}
local DEFAULT_COST = 0x30000   -- above every cost measured so far (max 0x26780)

local function cost_of(kind)
    return costs[kind] or DEFAULT_COST
end

-- True when the type's heap can hold `count` more actors plus a margin.
-- Without a measured cost it answers false (used by the last-resort guard).
local function can_afford(kind, count)
    local cost = costs[kind]
    local heap = heap_of(kind)
    if cost == nil or heap == nil then
        return false
    end
    local _, largest = heap_space(heap)
    return largest ~= nil and largest >= cost * count + HEAP_MARGIN
end

-- Authored spawns still to come in this area, per type. Rebuilt when a group
-- starts and decremented as authored entries spawn.
local need = {}
local started = {}
-- The game recycles a dead enemy's model instance for the next spawn of its
-- type (probe, run 2026-10-24: type F's heap stopped shrinking after 5
-- instances while 18 more spawned and died). Memory follows how many are
-- alive at once, not how many spawn. peak[kind] is the largest authored wave
-- of a type in the groups still to come; allocs[kind] counts the instances
-- this area has allocated so far (heap drops seen at spawns).
local peak = {}
local allocs = {}
local ENTITY_BASE   = 0x005D1AB8   -- char table; pool slot i is entity i
local ENTITY_STRIDE = 0x3238
local ENTITY_KIND   = 0x1DFE

-- Live actors of a type (pool slots 2-11 in use with that character ID).
-- Their instances are held, so they cannot be recycled for the next wave.
local function alive_of(kind)
    local flags = game.read_u32(CHAR_POOL + CHAR_FLAGS)
    if not plausible(flags) then
        return 0
    end
    local n = 0
    for i = 2, 11 do
        if game.read_u16(flags + i * 2) ~= 0
            and game.read_u16(ENTITY_BASE + i * ENTITY_STRIDE + ENTITY_KIND) == kind then
            n = n + 1
        end
    end
    return n
end

local function rebuild_need(current, current_orig)
    need = {}
    peak = {}
    for group = 0, GROUP_LIMIT - 1 do
        local base = group_base(group)
        if game.read_u8(base + ENABLED_OFFSET) ~= 0 then
            local count = group_count(base)
            if group == current then
                count = current_orig
            elseif started[group] then
                count = 0
            end
            if count then
                local wave = {}
                for slot = 0, count - 1 do
                    local kind = game.read_u32(entry_address(group, slot))
                    need[kind] = (need[kind] or 0) + 1
                    wave[kind] = (wave[kind] or 0) + 1
                end
                for kind, n in pairs(wave) do
                    if n > (peak[kind] or 0) then peak[kind] = n end
                end
            end
        end
    end
end

local function spawned_authored(kind)
    if need[kind] and need[kind] > 0 then
        need[kind] = need[kind] - 1
    end
end

-- Can one EXTRA actor of this type spawn without starving any authored spawn
-- left in the area? Dead enemies' instances are recycled, so it leaves room for
-- the part of the largest authored wave to come that the area's free
-- (allocated but not held by a live actor) instances don't cover, plus this
-- extra and one spare.
local function surplus_for(kind)
    local heap = heap_of(kind)
    if heap == nil then
        return false
    end
    local _, largest = heap_space(heap)
    if largest == nil then
        return false
    end
    local missing = (peak[kind] or 0) - ((allocs[kind] or 0) - alive_of(kind))
    if missing < 0 then missing = 0 end
    return largest >= (2 + missing) * cost_of(kind) + HEAP_MARGIN
end

-- Slot heaps only shrink until the area reloads, so free memory going back up
-- is a reliable reload signal even when the level-load hook does not fire.
local last_free = {}
local heap_kind = {}

local function memory_reloaded()
    local table_ptr, count = slot_table()
    if table_ptr == nil then
        return false
    end
    local grew = false
    for slot = 0, count - 1 do
        local heap = game.read_u32(table_ptr + slot * SLOT_STRIDE)
        local kind = game.read_u32(table_ptr + slot * SLOT_STRIDE + SLOT_TYPE)
        if heap < 0x80 then
            local free = heap_space(heap)
            if free then
                if last_free[heap] and free > last_free[heap] + 0x10000 then
                    grew = true
                    allocs[kind] = 0             -- rebuilt: no instances to recycle
                end
                last_free[heap] = free
            end
            if heap_kind[heap] ~= kind then
                heap_kind[heap] = kind
                allocs[kind] = 0                 -- a new type took this heap
            end
        end
    end
    return grew
end

-- Spawn measurement: snapshot every slot heap before 0x1D1D40, attribute the
-- largest drop afterwards to the type that owns that heap.
local snapshot = nil
-- Recycling evidence, session-wide (it's how the engine works, not a property
-- of one area): a spawn that succeeded without taking memory from its type's
-- heap reused a dead enemy's instance. Until one is seen, the spawn guard
-- only trusts fresh memory. v1 patch 2 (2026-10-24, ported to the dev line
-- 2026-10-25): instances are counted per heap lifetime, not per map: a type
-- that stays loaded across maps keeps its heap and instances (Goro's Lair,
-- type 0xF), and memory_reloaded() resets a heap's count when the heap is
-- rebuilt or another type takes it. Costs stay session-wide, so the guard is
-- never blind (patch 1 reset them per map and the Kitana fight crashed on a
-- spawn with no memory for its model).
local recycling_seen = false
local pending_entry = nil

local function measure_before(entry)
    local table_ptr, count = slot_table()
    snapshot = nil
    pending_entry = nil
    if entry and entry_index(entry) then
        pending_entry = entry        -- read its type afterwards: a clone may be retyped first
    end
    if table_ptr == nil then
        return
    end
    snapshot = {}
    for slot = 0, count - 1 do
        local base = table_ptr + slot * SLOT_STRIDE
        local heap = game.read_u32(base)
        local free = heap < 0x80 and heap_space(heap) or nil
        snapshot[slot] = { kind = game.read_u32(base + SLOT_TYPE), heap = heap, free = free }
    end
end

local function measure_after(result)
    if snapshot == nil then
        return
    end
    local spawned = nil
    if pending_entry and result and result ~= 0 then
        spawned = game.read_u32(pending_entry)
    end
    for _, slot in pairs(snapshot) do
        if slot.free then
            local now = heap_space(slot.heap)
            if now and now < slot.free then
                local used = slot.free - now
                if used > (costs[slot.kind] or 0) then
                    costs[slot.kind] = used
                end
                allocs[slot.kind] = (allocs[slot.kind] or 0) + 1
            elseif now and slot.kind == spawned then
                recycling_seen = true
            end
        end
    end
    snapshot = nil
end

-- Spawn guard: hide a type from the allowed-type table for one 0x1D1D40 call.
-- 0x1C1580 then rejects it before anything is allocated, the game treats it
-- like any failed spawn and moves on. guard_restore() must run in the after.
local hidden = nil

local function guard_hide(kind)
    for slot = 0, LOADED_SLOTS - 1 do
        local address = LOADED_TYPES + slot * 4
        if game.read_u32(address) == kind then
            game.write_u32(address, NO_TYPE)
            hidden = { address = address, kind = kind }
            return
        end
    end
end

local function guard_restore()
    if hidden then
        if game.read_u32(hidden.address) == NO_TYPE then
            game.write_u32(hidden.address, hidden.kind)
        end
        hidden = nil
    end
end

-- Last resort: cancel a spawn whose heap cannot hold one more actor of its
-- measured cost (the game would crash in 0x113EF0). No margin here, so an
-- authored spawn that fits is never touched. A dead enemy's instance is
-- recycled for the next spawn of its type (once this session has seen it
-- happen), so a spawn with a free instance (allocated this area, not held by
-- a live actor) needs no new memory. 2026-10-24
-- soft-lock: after LDK's extras used up type 0xF's fresh heap, the guard
-- cancelled every spawn of the fatality tutorial's respawning wave in Goro's
-- Lair; the room never got enemies and the gate never opened.
local function guard_spawn(entry)
    local kind = game.read_u32(entry)
    local heap = heap_of(kind)
    if costs[kind] == nil or heap == nil then
        return true
    end
    local _, largest = heap_space(heap)
    if largest ~= nil and largest < costs[kind]
        and not (recycling_seen and (allocs[kind] or 0) - alive_of(kind) > 0) then
        guard_hide(kind)
        return false
    end
    return true
end

local function free_char_slots()
    local flags = game.read_u32(CHAR_POOL + CHAR_FLAGS)
    local size = game.read_u32(CHAR_POOL_SIZE)
    if not plausible(flags) or size == 0 or size > 32 then
        return 0
    end
    local free = 0
    for slot = 0, size - 1 do
        if game.read_u16(flags + slot * 2) == 0 then
            free = free + 1
        end
    end
    return free
end

local function is_loaded(kind)
    if kind == NO_TYPE then
        return false
    end
    for slot = 0, LOADED_SLOTS - 1 do
        if game.read_u32(LOADED_TYPES + slot * 4) == kind then
            return true
        end
    end
    return false
end

-- Level census: how often each enemy type is authored across all groups.
-- Types authored once per level are bosses or elites and are never cloned
-- or re-rolled. The census is rebuilt whenever the loaded level changes.
local census = {}
local census_key = nil

-- Spawn entries carry per-slot behaviour that suits the authored enemy: the
-- spawn-near-player flag (+0x58) and anchor (+0x24), the initial AI state
-- (+0x5C, e.g. climbing in from outside the arena), patrol/target (+0x60),
-- navmesh (+0x70) and special-mover data (+0x10). A type may only move into
-- an entry whose behaviour signature matches an entry the area authors for
-- that type, or it can end up stuck out of bounds (an Oni dropped into a
-- wall-climber's slot).
local SIGNATURE_FIELDS = { 0x10, 0x24, 0x5C, 0x60, 0x70 }
local sig_types = {}            -- signature -> { [type] = true }
local GENERIC = -1              -- signature shared by every plain entry

-- A plain entry has no special entrance: no spawn-near-player flag, no
-- initial AI state (the spawner treats -1 and 0xA as none) and no special
-- mover data. Any regular enemy the area spawns from plain entries can use
-- any plain entry. Special entries keep an exact-match signature.
local function signature(entry)
    local flag = game.read_u8(entry + 0x58)
    local state = game.read_u32(entry + 0x5C)
    local mover = game.read_u32(entry + 0x10)
    if flag == 0 and (state == 0xFFFFFFFF or state == 0xA) and mover == 0xFFFFFFFF then
        return GENERIC
    end
    local sig = flag
    for _, offset in ipairs(SIGNATURE_FIELDS) do
        sig = (sig * 1000003 + game.read_u32(entry + offset)) & 0xFFFFFFFFFFFF
    end
    return sig
end

local function fits(kind, entry)
    local types = sig_types[signature(entry)]
    return types ~= nil and types[kind] == true
end

local function level_key()
    local key = 0
    for group = 0, GROUP_LIMIT - 1 do
        local base = group_base(group)
        key = (key * 31 + game.read_u32(base) + game.read_u32(base + 8) * 7
            + game.read_u32(base + 0xC) * 13) & 0xFFFFFFFF
    end
    return key
end

-- The census is built a few groups per callback (each callback has a
-- 100,000-instruction budget and a full level can hold 50 x 22 entries).
-- Until census_ready() the spawn mods leave every group as authored.
local CENSUS_STEP = 10
local census_next = GROUP_LIMIT

local function census_step()
    local last = census_next + CENSUS_STEP - 1
    if last > GROUP_LIMIT - 1 then
        last = GROUP_LIMIT - 1
    end
    for group = census_next, last do
        local base = group_base(group)
        if game.read_u8(base + ENABLED_OFFSET) ~= 0 then
            local count = group_count(base)
            if count then
                for slot = 0, count - 1 do
                    local entry = entry_address(group, slot)
                    local kind = game.read_u32(entry)
                    census[kind] = (census[kind] or 0) + 1
                    local sig = signature(entry)
                    local types = sig_types[sig] or {}
                    types[kind] = true
                    sig_types[sig] = types
                end
            end
        end
    end
    census_next = last + 1
    return census_next >= GROUP_LIMIT
end

local function census_ready()
    return census_key ~= nil and census_next >= GROUP_LIMIT
end

-- Starts a new census when the loaded level changed. Returns true then.
local function refresh_census()
    local key = level_key()
    if key == census_key then
        return false
    end
    census_key = key
    census = {}
    sig_types = {}
    census_next = 0
    reseed(key)
    census_step()
    return true
end

-- Bosses are never "common", however many times an area authors them: the
-- Oni Warlord is authored twice in its area, so census alone made it a
-- regular enemy that Shaolin Shuffle and LDK could move into a grunt's spawn
-- entry outside the arena. Super bosses are the critical-path giants; Mortal
-- Kombat characters are the human-sized bosses. Names as corrected on
-- 2026-11-01 (analysis/mk_roster: the old names were two types off); the
-- older entries keep their place in these sets whatever they turned out to be.
local SUPER_BOSSES = {
    [28] = true,               -- bladed humanoid (was thought to be an Orochi)
    [34] = true,               -- archer (was thought to be a club warlord)
    [36] = true,               -- Oni Warlord
    [45] = true,               -- swamp snake
    [47] = true, [57] = true,  -- Goro (the only two-slot types)
    [55] = true,               -- Scorpion, burned
    [56] = true,               -- Baraka
    [58] = true,               -- Kintaro
    [60] = true, [61] = true,  -- unnamed humanoids next to Shang Tsung
    [62] = true, [63] = true,  -- Shang Tsung, young and old
    [64] = true,               -- Shao Kahn
}
local MK_BOSSES = {
    [50] = true,               -- big snake (Reptile's arena)
    [51] = true,               -- unnamed creature
    [52] = true,               -- Scorpion
    [53] = true,               -- Noob Saibot
    [54] = true,               -- Kano
    [59] = true,               -- Reptile, story fight (map 144): authored in three
                               -- waves, so LDK cloned him as a common enemy (v1 patch 4)
    [65] = true,               -- Kitana
    [66] = true,               -- Mileena
    [67] = true,               -- Jade
    [68] = true,               -- Ermac
    [69] = true,               -- Sub-Zero
    [70] = true,               -- Smoke
    [71] = true,               -- Johnny Cage (story)
    [72] = true,               -- Raiden
    [74] = true,               -- Jax
    [78] = true,               -- Johnny Cage
    [81] = true,               -- Kintaro (morning star model)
    [82] = true, [88] = true,  -- Scorpion, Sub-Zero (playable models)
    [83] = true, [84] = true,  -- Baraka, Reptile (versus models)
    [85] = true, [86] = true,  -- Ermac (versus), Johnny Cage (stone)
    [89] = true, [90] = true,  -- Kitana, Johnny Cage (versus models)
}
local function is_boss(kind)
    return SUPER_BOSSES[kind] == true or MK_BOSSES[kind] == true
end

-- Fatality tutorial rooms (three in the game; Goro's Lair map 99 is one) gate
-- their exit on their own respawning wave and on a fatality. Changed waves
-- soft-locked map 99 twice on 2026-10-24, so an area whose map triggers test
-- isfatalityfull, fatalityover or fatalitytutor stays vanilla: LDK adds no
-- extras and Shuffle changes nothing there. Triggers: records 0xD8 apart from
-- [0x682020], count +0xA8C0, conditions +0x58 (count) / +0x5C (command slots);
-- a slot's command object is [mgr + slot*24 + 0x11C00], its execute [[obj]].
local TRIGGERS_PTR = 0x00682020
local FATALITY_TESTS = { [0x00013382] = true, [0x000166B3] = true, [0x000145ED] = true }
local fatality_seen_key, fatality_seen = nil, false

local function fatality_area()
    local mgr = game.read_u32(TRIGGERS_PTR)
    if not plausible(mgr) then
        return false
    end
    local count = game.read_u32(mgr + 0xA8C0)
    local key = mgr * 1000 + count
    if key == fatality_seen_key then
        return fatality_seen
    end
    fatality_seen_key, fatality_seen = key, false
    local commands = game.read_u32(mgr + 0x1254C)
    if count > 200 or commands > 200 then
        return false
    end
    for index = 0, count - 1 do
        local rec = mgr + index * 0xD8
        local n = game.read_u32(rec + 0x58)
        local slots = game.read_u32(rec + 0x5C)
        if n > 0 and n <= 12 and plausible(slots) then
            for j = 0, n - 1 do
                local slot = game.read_u32(slots + j * 4)
                if slot <= commands then
                    local object = game.read_u32(mgr + slot * 24 + 0x11C00)
                    local vtable = plausible(object) and game.read_u32(object) or 0
                    if plausible(vtable) and FATALITY_TESTS[game.read_u32(vtable)] then
                        fatality_seen = true
                        return true
                    end
                end
            end
        end
    end
    return false
end

local function is_common(kind)
    return kind ~= NO_TYPE and (census[kind] or 0) >= 2 and not is_boss(kind)
end

-- Time Rifts (a separate mod) builds its boss's spawn group itself and marks
-- it with this word in the group record's tail, which the spawn code never
-- reads (it reads only the count +0xA68 and the enabled byte +0xA6A there).
-- LDK and Shaolin Shuffle leave a marked group alone: no clones, no shuffle.
-- Time Rifts writes the same constants (time_rifts_body.lua).
local RIFT_MARK_OFFSET = 0xA10
local RIFT_MARK        = 0x54464952   -- "RIFT"
local function rift_group(base)
    return game.read_u32(base + RIFT_MARK_OFFSET) == RIFT_MARK
end

-- Shaolin Shuffle's outsider pool: regular enemy types (one memory slot
-- each) that a map's roster gains from another level (randomizer_body.lua).
-- LDK reads it too: such a type authored now but missing from the census
-- (built before Shuffle converted entries into it) is Shuffle's outsider,
-- with a fresh heap of its own. The Living Forest's tree mouth (42) and tree
-- arms (43) left it (Shuffle 0.12.1): hazards a wave doesn't count, hard to
-- kill, that stayed in the room after its wave.
local OUTSIDERS = { 10, 11, 12, 13, 14, 15, 26, 27, 18 }
-- ===== end shared spawn core =====

-- ===== Shaolin Shuffle 0.12.1 =====
-- 0.12.1: no more tree mouths or tree arms as outsiders (OUTSIDERS, core.lua).
-- 0.12.0: Mortal Kombat warriors (see MK_WARRIORS below).
-- 0.11.5: the shared boss list (core.lua) with corrected character names
-- covers every Mortal Kombat character.
-- Shuffles enemy types across every spawn slot of the current area. Model
-- memory is never freed when an enemy dies, and each type's heap is sized
-- for how many of it the area authors in total. A shuffle keeps those totals
-- exactly, so memory use stays vanilla however much changes. The shuffle is
-- planned and written in one spawn-tick callback per area (at most MAX_SLOTS
-- writes), so the per-type totals other mods read are never half-applied. Bosses and once-per-area elites keep their places, as do
-- characters without an enemy memory slot (players, allies).
local LOAD_GROUPS = 0x00014D2C
local START_GROUP = 0x001D2600
local SPAWN_ENTRY = 0x001D1D40
local SPAWN_TICK  = 0x001D23F0
local FIX_PASSES  = 3            -- passes that swap away unchanged entries
local MAX_SLOTS   = 150          -- entries shuffled per area (write and instruction budgets)

-- 0.7: outsiders. An area that preloads a single regular enemy type (Goro's
-- Lair: type 0xF only) has nothing to shuffle. The map's roster is a static,
-- writable preload list read by 0xCFAB0(desc) (thunk 0x15DEE) after the spawn
-- groups load: desc+0x24 holds -1 terminated character IDs, and desc+0x20 is
-- how many listed types may be missing before the whole preload is skipped.
-- Appending one regular type from another level makes the game load it into a
-- free memory slot itself, with its own heap. The shuffle then turns plain
-- entries into it: OUTSIDER_MIN in every group that has a plain entry (0.8:
-- every room gets one, the area's first group included), and OUTSIDER_CHANCE
-- percent of the rest, up to OUTSIDER_PER_GROUP per group and OUTSIDER_TOTAL
-- per area (0.11: the old Wild variant's values, now the only setting).
--
-- There are 4 enemy memory slots. Over 164 logged group starts, vanilla never
-- had more than 3 enemy types loaded at once, so the outsider takes the slot
-- the game leaves spare. Scripted loads (modelstream, 0x17BA00) go through the
-- replace queue (0x17BA40), which unloads whatever holds the target slot
-- first, so a cutscene can still evict the outsider. If that happens, the
-- converted entries go back to their own type and the area keeps its authored
-- roster from then on. The outsider pool is the regular types the probe saw
-- spawning as common enemies; all of them need one memory slot. 0.9 widened it
-- with the types the QA logs' area census saw as commons in 7+ areas.
--
-- 0.11: cross-area everywhere. Any map whose roster has a regular type gets an
-- outsider, as long as the roster plus the outsider fit in SLOT_BUDGET of the
-- 4 enemy memory slots. Each listed type costs its character-table slots
-- (+0x04: 1, or 2 for IDs 47 and 57), bosses and MK characters included. A
-- budget of 3 is vanilla's own observed maximum and keeps one slot spare for
-- scripted loads and types a level streams in on the spot. Every slot heap is
-- the same fixed size (0x232000), so the outsider's memory doesn't depend on
-- what the area authors. The list is a -1 padded array of 8 words, so one
-- more entry always fits; the words it overwrites are cached and restored.
--
-- 0.11.1: most of the main path preloads 3 types (QA run 2026-10-31: maps
-- 101, 104, 107, 192 all did), so 0.11.0 left it untouched. The budget rises
-- to all 4 slots (vanilla's own preload fills 4 on six maps) when the area's
-- spawn groups, which load before the preload, author no type the roster
-- doesn't list: then nothing in the level streams in on the spot, and a
-- cutscene's modelstream still evicts the outsider cleanly (release_outsider).
-- The scan only counts when this area's groups loaded since the last preload.
--
-- 0.11.3: 0.11.2 had the outsider replace one of the roster's common types
-- on maps that load three. It crashed loading the Wu Shi entrance (map 104,
-- roster 14/71/77; QA 2026-10-31 14:06 and 14:12, a null+0x68 read in the
-- loader's frame): the map's scene places characters of its listed types
-- outside the spawn groups, so every listed type must stay loaded. Removed;
-- the roster is only ever added to.
--
-- 0.11.4: a cutscene evicting the outsider and a re-shuffle could fall in one
-- spawn tick: up to 45 restored entries plus a whole shuffle (243 writes) is
-- over the runtime's 256 writes per callback, which disables the script. The
-- restore now has its tick to itself. Groups Time Rifts marks as its own
-- (core.lua) are never shuffled or converted. The outsider pool moved to
-- core.lua, so LDK can recognise the outsider.
local PRELOAD            = 0x00015DEE
local DESC_CAP           = 0x20
local DESC_LIST          = 0x24
local LIST_WORDS         = 8
local CHAR_TABLE         = 0x004FA9F0   -- 91 rows of 0x30, by character ID
local CHAR_ROW           = 0x30
local CHAR_SLOTS         = 0x04
local SLOT_BUDGET        = 3            -- when the level may stream a type in on the spot
local SLOT_BUDGET_FULL   = 4            -- when every authored type is in the roster
local GAME_MANAGER       = 0x005ACEBC
local GAME_MODE          = 0x88         -- 2 = versus
-- 0.11: one mod with what was the Wild variant: the v1 pool plus the regular
-- types the QA logs saw as commons in 7+ areas (OUTSIDERS, in core.lua).
local OUTSIDER_MIN       = 1            -- outsiders guaranteed per group with a plain entry
local OUTSIDER_CHANCE    = 50           -- percent of the other plain entries that also become one
local OUTSIDER_PER_GROUP = 5
local OUTSIDER_TOTAL     = 45
-- 0.12: Mortal Kombat warriors. An area that gets an outsider gets one of
-- these instead MK_CHANCE percent of the time: a human-sized Mortal Kombat
-- character with one memory slot and animations of its own
-- (analysis/mk_roster). Two things about them come from the game:
-- * Their per-character AI setup (the switch on the type at 0xE2F11) makes
--   most of them unkillable for their scripted boss fights: actor +0xD4 = 0,
--   and TakeDamage (0x153E20) then stops their health at 1 so the fight's
--   script can play its ending. Shuffle sets +0xD4 back to 1 on every live
--   warrior of its own (keep_killable).
-- * Character table +0x08 is how many model copies the type's memory slot is
--   built for (tgtProcessObjectModel 0x113B50): 2 for these. So only
--   MK_PER_AREA entries, one per group, become the warrior, and an entry
--   that would spawn one copy too many goes back to its own type first
--   (keep_copies).
-- No warrior where the roster lists a boss (a boss arena), where the area's
-- spawn groups author the warrior's type (its own scripted fight), or when the
-- groups weren't freshly loaded (they can't be checked).
local MK_WARRIORS        = { 52, 54, 55, 56, 59, 65, 66, 67, 68, 69 }
local MK_CHANCE          = 35           -- percent of outsider areas that get a warrior instead
local MK_PER_AREA        = 2
local CHAR_COPIES        = 0x08         -- character table: model copies the type's slot holds
local ACTOR              = 0x200        -- entity: its actor
local CAN_KILL           = 0xD4         -- actor: 0 = its health stops at 1
local warrior_kinds = {}
for _, kind in ipairs(MK_WARRIORS) do
    warrior_kinds[kind] = true
end
-- 0.10: room mixing. An area whose rooms each author one enemy type shows no
-- variety from the signature-class swap alone, and (before 0.11) the outsider
-- path needed a single-type roster. So it also swaps plain entries between two types
-- in different rooms: each swap keeps both per-type totals exact (the heap
-- invariant), and the room that gave an entry gains one of the other type.
local MIX_PER_ROOM       = 1            -- pairs swapped into each single-type room
local MIX_TOTAL          = 24            -- pairs per area (a pair is two writes)

local planned = false
local witnesses = {}             -- a few shuffled entries; a revert means a reload
local area_serial = 0            -- bumped when an area's spawn groups load
local preload_serial = 0         -- area_serial at the last preload (0: no groups loaded yet)
local rosters = {}               -- desc -> authored { cap, list = {types}, after = {next two words} }
local outsider = nil             -- { kind, desc, area } chosen for the loading area
local released = nil             -- { desc, area } whose outsider was evicted
local converted = {}             -- { entry, from } turned into the outsider

local function versus()
    local manager = game.read_u32(GAME_MANAGER)
    return plausible(manager) and game.read_u32(manager + GAME_MODE) == 2
end

-- Memory slots a character needs (character table +0x04: 1, or 2).
local function slots_needed(kind)
    if kind > 90 then
        return 1
    end
    local slots = game.read_u32(CHAR_TABLE + kind * CHAR_ROW + CHAR_SLOTS)
    if slots < 1 or slots > 2 then
        return 1
    end
    return slots
end

-- The map's authored roster, read on the first visit (the list is static, and
-- later visits find our outsider in it).
local function authored_roster(desc)
    local roster = rosters[desc]
    if roster ~= nil then
        return roster
    end
    roster = { cap = game.read_u32(desc + DESC_CAP), list = {}, after = {} }
    for i = 0, LIST_WORDS - 1 do
        local kind = game.read_u32(desc + DESC_LIST + i * 4)
        if kind == NO_TYPE then
            break
        end
        roster.list[#roster.list + 1] = kind
    end
    local n = #roster.list
    if n + 2 <= LIST_WORDS then
        roster.after = { game.read_u32(desc + DESC_LIST + n * 4), game.read_u32(desc + DESC_LIST + (n + 1) * 4) }
    end
    rosters[desc] = roster
    return roster
end

-- Whether a roster can take an outsider: it has a regular type for the
-- outsider to stand in for, room in the list, and the slot budget left.
local function takes_outsider(roster, budget)
    local n = #roster.list
    if n == 0 or n + 2 > LIST_WORDS then
        return false
    end
    local regular, slots = false, 1
    for _, kind in ipairs(roster.list) do
        if kind >= 2 and kind <= 49 and not is_boss(kind) then
            regular = true
        end
        slots = slots + slots_needed(kind)
    end
    return regular and slots <= budget
end

-- Every character the area's spawn groups author (disabled groups included:
-- a trigger may enable them later).
local function authored_types()
    local authored = {}
    -- worst case 50 x 22 reads, so the address math is inlined (instruction budget)
    local read = game.read_u32
    for base = MANAGER, MANAGER_END - 1, GROUP_STRIDE do
        local count = game.read_u16(base + COUNT_OFFSET)
        if count > ENTRY_SLOTS then
            count = 0
        end
        local entry = base + ENTRY_BASE
        for _ = 1, count do
            authored[read(entry)] = true
            entry = entry + ENTRY_STRIDE
        end
    end
    return authored
end

-- Whether the area's spawn groups author a character the roster doesn't list.
-- The game streams such a type in on the spot when its group starts, into a
-- free slot.
local function streams_on_the_spot(roster, authored)
    local listed = {}
    for _, kind in ipairs(roster.list) do
        listed[kind] = true
    end
    for kind in pairs(authored) do
        if kind <= 90 and not listed[kind] then
            return true
        end
    end
    return false
end

-- The Mortal Kombat warriors this area may take (none in a boss arena).
local function warrior_pool(roster, own, authored)
    for _, kind in ipairs(roster.list) do
        if is_boss(kind) then
            return {}
        end
    end
    local pool = {}
    for _, kind in ipairs(MK_WARRIORS) do
        if not own[kind] and not authored[kind] then
            pool[#pool + 1] = kind
        end
    end
    return pool
end

-- Runs before 0xCFAB0 reads the preload list. Restores the map's authored
-- roster (an earlier visit may have changed this static list) and, when the
-- roster fits the slot budget, appends an outsider. A re-preload in the same
-- area (0xD1910, after a cutscene) keeps the same outsider.
local function plan_preload(desc)
    if not plausible(desc) or desc >= 0x01000000 then
        return
    end
    local roster = authored_roster(desc)
    local n = #roster.list
    local kind = nil
    local evicted = released and released.desc == desc and released.area == area_serial
    local fresh = preload_serial ~= area_serial          -- this area's groups loaded since the last preload
    preload_serial = area_serial
    local eligible = not fatality_area() and not evicted and not versus()
    if eligible and outsider and outsider.desc == desc and outsider.area == area_serial then
        kind = outsider.kind                             -- a re-preload (0xD1910) keeps it
    elseif eligible then
        local authored = fresh and authored_types() or nil
        local budget = SLOT_BUDGET
        if authored and not streams_on_the_spot(roster, authored) then
            budget = SLOT_BUDGET_FULL
        end
        if takes_outsider(roster, budget) then
            reseed(desc ~ area_serial)
            local own, pool = {}, {}
            for _, k in ipairs(roster.list) do
                own[k] = true
            end
            if authored and rnd() % 100 < MK_CHANCE then
                pool = warrior_pool(roster, own, authored)
            end
            if #pool == 0 then
                for _, candidate in ipairs(OUTSIDERS) do
                    if not own[candidate] then
                        pool[#pool + 1] = candidate
                    end
                end
            end
            if #pool > 0 then
                kind = pool[rnd() % #pool + 1]
            end
        end
    end
    for i, k in ipairs(roster.list) do
        local at = desc + DESC_LIST + (i - 1) * 4
        if game.read_u32(at) ~= k then
            game.write_u32(at, k)
        end
    end
    local slot = desc + DESC_LIST + n * 4
    if kind then
        game.write_u32(slot, kind)
        game.write_u32(slot + 4, NO_TYPE)
        if roster.cap < n + 1 then
            game.write_u32(desc + DESC_CAP, n + 1)
        end
        outsider = { kind = kind, desc = desc, area = area_serial }
        return
    end
    if #roster.after == 2 and game.read_u32(slot) ~= roster.after[1] then
        game.write_u32(slot, roster.after[1])
        game.write_u32(slot + 4, roster.after[2])
    end
    if game.read_u32(desc + DESC_CAP) ~= roster.cap then
        game.write_u32(desc + DESC_CAP, roster.cap)
    end
    outsider = nil               -- every map load preloads its own roster
end

-- The outsider type when it is loaded for this area, else nil.
local function outsider_kind()
    if outsider == nil then
        return nil
    end
    if is_loaded(outsider.kind) and heap_of(outsider.kind) ~= nil then
        return outsider.kind
    end
    return nil
end

-- A cutscene's modelstream evicted the outsider: put the converted entries
-- back to their own type so they don't stream it into another free slot.
-- True when it did (the callback's writes are then spent on it).
local function release_outsider()
    if #converted == 0 or outsider == nil or is_loaded(outsider.kind) then
        return false
    end
    for _, c in ipairs(converted) do
        if game.read_u32(c.entry) == outsider.kind then
            game.write_u32(c.entry, c.from)
        end
    end
    converted = {}
    -- those entries now hold their own type again: not a sign of a reload
    local kept = {}
    for _, w in ipairs(witnesses) do
        if w.to ~= outsider.kind then
            kept[#kept + 1] = w
        end
    end
    witnesses = kept
    released = { desc = outsider.desc, area = area_serial }
    outsider = nil
    return true
end

-- Turn plain entries into the outsider: OUTSIDER_MIN per group first, so every
-- room gets one, then OUTSIDER_CHANCE percent of the rest, within
-- OUTSIDER_PER_GROUP per group and OUTSIDER_TOTAL per area. A re-plan that
-- finds earlier conversions still in place keeps them instead of adding more.
local function convert_outsiders(plain)
    local kind = outsider_kind()
    if kind == nil then
        converted = {}
        return
    end
    local kept = {}
    for _, c in ipairs(converted) do
        if game.read_u32(c.entry) == kind then
            kept[#kept + 1] = c
        end
    end
    converted = kept
    if #converted > 0 then
        return
    end
    for i = #plain, 2, -1 do
        local j = rnd() % i + 1
        plain[i], plain[j] = plain[j], plain[i]
    end
    local total, group_cap, chance = OUTSIDER_TOTAL, OUTSIDER_PER_GROUP, OUTSIDER_CHANCE
    if warrior_kinds[kind] then
        total, group_cap, chance = MK_PER_AREA, 1, 0
    end
    local per_group = {}
    local function convert(slot)
        local from = game.read_u32(slot.entry)
        if from == kind then
            return
        end
        game.write_u32(slot.entry, kind)
        converted[#converted + 1] = { entry = slot.entry, from = from }
        per_group[slot.group] = (per_group[slot.group] or 0) + 1
        slot.done = true
        if #witnesses < 4 then
            witnesses[#witnesses + 1] = { entry = slot.entry, from = from, to = kind }
        end
    end
    for _, slot in ipairs(plain) do
        if #converted >= total then
            return
        end
        if (per_group[slot.group] or 0) < OUTSIDER_MIN then
            convert(slot)
        end
    end
    for _, slot in ipairs(plain) do
        if #converted >= total then
            return
        end
        if not slot.done and (per_group[slot.group] or 0) < group_cap
            and rnd() % 100 < chance then
            convert(slot)
        end
    end
end

-- This area's live Mortal Kombat warriors stay killable: their AI setup set
-- +0xD4 to 0 for a scripted boss fight they aren't in. At most a few writes.
local function keep_killable()
    local kind = outsider and outsider.kind
    if not warrior_kinds[kind] then
        return
    end
    local flags = game.read_u32(CHAR_POOL + CHAR_FLAGS)
    if not plausible(flags) then
        return
    end
    for i = 2, 11 do
        local entity = ENTITY_BASE + i * ENTITY_STRIDE
        if game.read_u16(flags + i * 2) ~= 0 and game.read_u16(entity + ENTITY_KIND) == kind then
            local actor = game.read_u32(entity + ACTOR)
            if plausible(actor) and game.read_u8(actor + CAN_KILL) == 0 then
                game.write_u8(actor + CAN_KILL, 1)
            end
        end
    end
end

-- A warrior entry about to spawn one copy more than the type's slot holds
-- goes back to its own type for good.
local function keep_copies(entry)
    local kind = outsider and outsider.kind
    if not warrior_kinds[kind] or game.read_u32(entry) ~= kind then
        return
    end
    local copies = game.read_u32(CHAR_TABLE + kind * CHAR_ROW + CHAR_COPIES)
    if copies < 1 or copies > 66 then
        copies = 2
    end
    if alive_of(kind) < copies then
        return
    end
    for _, c in ipairs(converted) do
        if c.entry == entry then
            game.write_u32(entry, c.from)
            return
        end
    end
end

-- Swap plain entries between rooms so a room that authors a single regular
-- type ends up spawning two. Each pair moves one entry each way, so every
-- type's area total, and with it its heap use, stays exactly as authored.
local function mix_rooms(plain)
    if MIX_PER_ROOM == 0 then
        return
    end
    local per_group, stacks = {}, {}
    for _, p in ipairs(plain) do
        local kind = game.read_u32(p.entry)   -- the class swap has permuted kinds since
        local list = per_group[p.group]
        if list == nil then
            list = {}
            per_group[p.group] = list
        end
        local entries = list[kind]
        if entries == nil then
            entries = {}
            list[kind] = entries
        end
        entries[#entries + 1] = p
        local stack = stacks[kind]
        if stack == nil then
            stack = {}
            stacks[kind] = stack
        end
        stack[#stack + 1] = p
    end
    local kinds, groups = {}, {}
    for k in pairs(stacks) do
        kinds[#kinds + 1] = k
    end
    for g in pairs(per_group) do
        groups[#groups + 1] = g
    end
    table.sort(kinds)
    table.sort(groups)
    local swapped = 0
    for _, group in ipairs(groups) do
        local list, own = per_group[group], {}
        for k, entries in pairs(list) do
            if #entries > 0 then
                own[#own + 1] = k
            end
        end
        if #own == 1 then
            local a, order = own[1], {}
            for _, k in ipairs(kinds) do
                if k ~= a then
                    order[#order + 1] = k
                end
            end
            while #order > 0 and swapped < MIX_TOTAL do
                local b = table.remove(order, rnd() % #order + 1)
                for _ = 1, MIX_PER_ROOM do
                    if #list[a] == 0 or swapped >= MIX_TOTAL then
                        break
                    end
                    local stack, eb = stacks[b], nil
                    for i = #stack, 1, -1 do
                        if stack[i].group ~= group and not stack[i].done then
                            eb = table.remove(stack, i)
                            break
                        end
                    end
                    if eb == nil then
                        break
                    end
                    local ea = table.remove(list[a], rnd() % #list[a] + 1)
                    local other = per_group[eb.group][b]
                    for i = 1, #other do
                        if other[i] == eb then
                            table.remove(other, i)
                            break
                        end
                    end
                    game.write_u32(ea.entry, b)
                    game.write_u32(eb.entry, a)
                    ea.done, eb.done = true, true
                    if #witnesses < 4 then
                        witnesses[#witnesses + 1] = { entry = ea.entry, from = a, to = b }
                    end
                    swapped = swapped + 1
                end
            end
        end
    end
end

local function shuffle_area(skip_started)
    planned = true
    if fatality_area() then
        return                   -- fatality room: vanilla (core.lua)
    end
    local classes = {}           -- signature -> { slots = {}, kinds = {} }
    local eligible = {}          -- type -> may be shuffled (cached per call)
    local plain = {}             -- plain eligible entries, outsider candidates
    local total = 0
    for group = 0, GROUP_LIMIT - 1 do
        local base = group_base(group)
        if game.read_u8(base + ENABLED_OFFSET) ~= 0 and not skip_started[group] and not rift_group(base) then
            local count = group_count(base)
            for slot = 0, (count or 0) - 1 do
                local kind = game.read_u32(entry_address(group, slot))
                local ok = eligible[kind]
                if ok == nil then
                    ok = is_common(kind) and is_loaded(kind) and heap_of(kind) ~= nil
                    eligible[kind] = ok
                end
                if total < MAX_SLOTS and ok then
                    local entry = entry_address(group, slot)
                    local sig = signature(entry)
                    local class = classes[sig] or { slots = {}, kinds = {} }
                    class.slots[#class.slots + 1] = { entry = entry, from = kind }
                    class.kinds[#class.kinds + 1] = kind
                    classes[sig] = class
                    total = total + 1
                    if sig == GENERIC then
                        plain[#plain + 1] = { entry = entry, group = group, kind = kind }
                    end
                end
            end
        end
    end
    -- the group spawning now stays out of the shuffle, but its entries that
    -- haven't spawned yet can still take the outsider (0.8: the area's first
    -- room gets one too)
    if game.read_u8(MANAGER + ST_ACTIVE) ~= 0 then
        local group = game.read_u16(MANAGER + ST_GROUP)
        local base = group_base(group)
        if group < GROUP_LIMIT and skip_started[group] and game.read_u8(base + ENABLED_OFFSET) ~= 0
                and not rift_group(base) then
            local count = group_count(base) or 0
            for slot = game.read_u16(MANAGER + ST_SPAWNED), count - 1 do
                local entry = entry_address(group, slot)
                local kind = game.read_u32(entry)
                local ok = eligible[kind]
                if ok == nil then
                    ok = is_common(kind) and is_loaded(kind) and heap_of(kind) ~= nil
                    eligible[kind] = ok
                end
                if ok and signature(entry) == GENERIC then
                    plain[#plain + 1] = { entry = entry, group = group, kind = kind }
                end
            end
        end
    end
    witnesses = {}
    for _, class in pairs(classes) do
        local slots, kinds = class.slots, class.kinds
        local n = #kinds
        for i = n, 2, -1 do
            local j = rnd() % i + 1
            kinds[i], kinds[j] = kinds[j], kinds[i]
        end
        -- Swap away entries that kept their own type where a swap changes both.
        for _ = 1, FIX_PASSES do
            for i = 1, n do
                if kinds[i] == slots[i].from then
                    local j = rnd() % n + 1
                    if kinds[j] ~= slots[i].from and kinds[i] ~= slots[j].from then
                        kinds[i], kinds[j] = kinds[j], kinds[i]
                    end
                end
            end
        end
        for i = 1, n do
            if kinds[i] ~= slots[i].from then
                game.write_u32(slots[i].entry, kinds[i])
                if #witnesses < 4 then
                    witnesses[#witnesses + 1] = { entry = slots[i].entry, from = slots[i].from, to = kinds[i] }
                end
            end
        end
    end
    mix_rooms(plain)
    convert_outsiders(plain)
end

local function reverted()
    for _, w in ipairs(witnesses) do
        if game.read_u32(w.entry) == w.from then
            return true
        end
    end
    return false
end

local seen_started = {}

local hooks = {
    {
        address = LOAD_GROUPS,
        after = function(ctx)
            census_key = nil
            planned = false
            seen_started = {}
            area_serial = area_serial + 1
            converted = {}
        end,
    },
    {
        address = PRELOAD,
        before = function(ctx)
            plan_preload(game.read_u32(ctx.esp + 4))
        end,
    },
    {
        address = START_GROUP,
        before = function(ctx)
            if ctx.ecx ~= MANAGER then
                return
            end
            local index = game.read_u32(ctx.esp + 4)
            if index >= GROUP_LIMIT then
                return
            end
            local reloaded = memory_reloaded()   -- also resets instance counts per heap (core.lua)
            if refresh_census() or reloaded or (planned and reverted()) then
                planned = false
                seen_started = {}
            end
            -- groups that already ran, and this one (another mod may have
            -- expanded it already), stay out of the area's shuffle
            seen_started[index] = true
            -- the shuffle runs in the next spawn tick, its own callback, so the
            -- census and the shuffle never share one instruction budget
        end,
    },
    {
        address = SPAWN_TICK,
        before = function(ctx)
            if ctx.ecx ~= MANAGER then
                return
            end
            keep_killable()
            if release_outsider() then
                return               -- the re-plan waits for the next tick (write budget)
            end
            if census_key == nil or planned then
                return
            end
            if not census_ready() then
                census_step()
            else
                shuffle_area(seen_started)
            end
        end,
    },
    {
        address = SPAWN_ENTRY,
        before = function(ctx)
            local entry = game.read_u32(ctx.esp + 4)
            if ctx.ecx == MANAGER and entry_index(entry) then
                keep_copies(entry)
            end
            measure_before(entry)
            if ctx.ecx ~= MANAGER then
                return
            end
            if entry_index(entry) then
                guard_spawn(entry)
            end
        end,
        after = function(ctx)
            guard_restore()
            measure_after(ctx.eax)
        end,
    },
}

return hooks
